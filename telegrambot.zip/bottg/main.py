import random
import telebot
import webbrowser
from telebot import types

bot = telebot.TeleBot("5973005435:AAE6CRbOfkujGBSv05XzWi4qJPdSBmcK5_M")


answers = ['не пон', '???', 'я тебя не понимаю', 'чооо']


@bot.message_handler(commands=['start'])
def welcome(message):

    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    button1 = types.KeyboardButton('🎵 Биты')
    button2 = types.KeyboardButton('⚙ Пресеты')
    button3 = types.KeyboardButton('🗨 Связь со мной')
    button4 = types.KeyboardButton('🎶 Тгк с драм китами')

    markup.row(button1, button2)
    markup.row(button3, button4)

    if message.text == '/start':

        bot.send_message(message.chat.id, f'Привет, {message.from_user.first_name}!\nУ меня ты можешь купить бит и взять бесплатные пресеты\nМой тг https://t.me/zxcasdqwe123qqq', reply_markup=markup)
    else:
        bot.send_message(message.chat.id, 'Хорошо...', reply_markup=markup)


@bot.message_handler(content_types='photo')
def get_photo(message):
    bot.send_message(message.chat.id, 'ты чо, я же бот')


@bot.message_handler()
def info(message):
    if message.text == '🎵 Биты':
        goodsChapter(message)
    elif message.text == '⚙ Пресеты':
        settingsChapter(message)
    elif message.text == '🗨 Связь со мной':
        infoChapter(message)
    elif message.text == '🎶 Тгк с драм китами':
        bot.send_message(message.chat.id, 'https://t.me/yakittidoblessed')



    elif message.text == 'New Jazz type beat':
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        button1 = types.KeyboardButton('💲Купить')
        button2 = types.KeyboardButton('Назад')
        markup.row(button1, button2)
        audio = open(r'C:\Users\user\Desktop\Биты тг\paparazzi (F minor,128bpm) @yakittido + @zestymain.mp3', 'rb')
        bot.send_message(message.chat.id, 'ребят🥹, что-то opium!🥶 немного поднадоел..😶‍🌫️решил перейти на new-rock?🩸'
                                          '🎸 new jazzik!? 🎻🎼 tununu teununun🎺 tununu teununun🎷 tununu teununun🥶'
                                          ' tununu teununun🤣 tununu teununun🥺', reply_markup=markup)
        bot.send_audio(message.chat.id, audio)
    elif message.text == 'Destroy Lonely type beat':
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        button1 = types.KeyboardButton('💲Купить')
        button2 = types.KeyboardButton('Назад')
        markup.row(button1, button2)
        audio = open(r'C:\Users\user\Desktop\Биты тг\god strength (E♭ minor,142bpm) @yakittido + @ardaizo.mp3', 'rb')
        bot.send_message(message.chat.id, 'never ever', reply_markup=markup)
        bot.send_audio(message.chat.id, audio)
    elif message.text == 'Chief Keef type beat':
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        button1 = types.KeyboardButton('💲Купить')
        button2 = types.KeyboardButton('Назад')
        markup.row(button1, button2)
        audio = open(r'C:\Users\user\Desktop\Биты тг\evil empire (E♭ minor,155bpm) @yakittido + @baby kin go + @real_lizgin.mp3', 'rb')
        bot.send_message(message.chat.id, 'однажды чиф киф сбил машину, теперь пешеходы ходят отдельно на тротуаре', reply_markup=markup)
        bot.send_audio(message.chat.id, audio)
    elif message.text == 'Yeat type beat':
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        button1 = types.KeyboardButton('💲Купить')
        button2 = types.KeyboardButton('Назад')
        markup.row(button1, button2)
        audio = open(r'C:\Users\user\Desktop\Биты тг\yeat (C minor,146bpm) @yakittido + @aash + @holdupnelly.mp3', 'rb')
        bot.send_message(message.chat.id, 'ай вонт бентли ай вонт мани', reply_markup=markup)
        bot.send_audio(message.chat.id, audio)


    elif message.text == 'Пресет Fendiglock':
        bot.send_message(message.chat.id, 'https://drive.google.com/file/d/1fk5Ohs13wNpSRRrsUC36dtM4vcHtnoLJ/view')
    elif message.text == 'Пресет Scally milano + Uglystephan':
        bot.send_message(message.chat.id, 'https://drive.google.com/drive/folders/19mlE4jqF7_Nqp6l0wRvlvW8AaCYMKUZE')
    elif message.text == 'Купить' or message.text == 'Связь со мной ':

        webbrowser.open('https://t.me/zxcasdqwe123qqq')
    elif message.text == 'Назад':
        goodsChapter(message)
    elif message.text == 'Назад в меню':
        welcome(message)

    else:
        bot.send_message(message.chat.id, answers[random.randint(0, 3)])


def goodsChapter(message):

    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    button1 = types.KeyboardButton('New Jazz type beat')
    button2 = types.KeyboardButton('Destroy Lonely type beat')
    button3 = types.KeyboardButton('Chief Keef type beat')
    button4 = types.KeyboardButton('Yeat type beat')
    button5 = types.KeyboardButton('Назад в меню')
    markup.row(button1, button2)
    markup.row(button3, button4)
    markup.row(button5)

    bot.send_message(message.chat.id, 'Выбери тайп бита :', reply_markup=markup)


def settingsChapter(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    button1 = types.KeyboardButton('Пресет Fendiglock')
    button2 = types.KeyboardButton('Пресет Scally milano + Uglystephan')
    button3 = types.KeyboardButton('Назад в меню')
    markup.row(button1, button2)
    markup.row(button3)
    bot.send_message(message.chat.id, 'Пресеты \nВыбери какой тебе нужен :', reply_markup=markup)

def infoChapter(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    button1 = types.KeyboardButton('Назад в меню')
    markup.row(button1)
    bot.send_message(message.chat.id, 'Написать мне:\nhttps://t.me/zxcasdqwe123qqq ', reply_markup=markup)


bot.polling(none_stop=True)